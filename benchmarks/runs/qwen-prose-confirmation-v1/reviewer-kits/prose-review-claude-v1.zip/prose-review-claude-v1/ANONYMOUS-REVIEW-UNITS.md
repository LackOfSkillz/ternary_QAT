# Anonymous Review Units

Score every unit below in the supplied YAML or JSON score template. Units are in a randomized order.

## Review Unit: unit-f34f9b2949213419

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

SOURCE:
The lamp guttered twice and held. Outside, the tide worked at the pilings the way it always had, patient and without opinion.

### Anonymous Output

{"changed": false, "reason": "clean", "text": "The lamp guttered twice and held. Outside, the tide worked at the pilings the way it always had, patient and without opinion."}

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-d29fdb81f75be5ab

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

### Anonymous Output

Edith opened the bottom drawer of the dresser with a slow, deliberate motion, as though the act itself were a ritual. The wood groaned faintly beneath her fingers, a sound she had come to associate with the passage of time. She lifted the oilcloth logbooks with both hands, their edges worn and their weight familiar. They sat in a neat stack, each one bound with care, their spines marked in careful script. She traced the last one with her thumb, noting its place—just before the end. A strange unease prickled at her, though she did not yet know why. She set the stack aside, her fingers lingering on the edge of the drawer. A small, silver hairpin caught the light as she pulled it free, its prongs still slightly bent from a previous use. She held it up, watching the way the afternoon sun caught the metal, before slipping it into her palm and turning back to the logbooks.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-e700b906ba28eccc

### Task

This passage is built almost entirely from eye movement. Keep at most one meaningful look and let motivated action carry the rest. Preserve the power dynamic; do not explain the look.

SOURCE:
Their eyes met across the workshop. She looked away. His gaze followed her. Her eyes widened as he stepped nearer, and their eyes locked again. She watched him, and he watched her back, neither willing to look away first.

### Anonymous Output

Their eyes met across the workshop. She looked away. He stepped closer. She watched him, and he watched her back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-d4b97057797ecc30

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

### Anonymous Output

Edith opened the bottom drawer of the dresser with a slow, deliberate motion, as though the act itself were a ritual. The wood groaned faintly, a sound she had come to associate with the passage of time. She lifted out the oilcloth logbooks, their edges stiff with age, their covers worn smooth by years of use. She held them in her hands, feeling the weight of each one, the way they stacked in neat, orderly rows. The last book, however, was out of place—slightly shifted, as if it had been moved recently. She noted the absence of its usual position without thinking about it, her mind already cataloging the anomaly. Her fingers traced the spine of the missing book, the faint scent of ink and paper rising from the stack. She set the pile down carefully, then reached for a cloth to wipe the dust from the drawer’s interior.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-aba251af8597a351

### Task

Terse, plain register. This line has one mixed metaphor. Repair only that; keep it plain and short. Source: 'The debt was a fire that flooded him and left him underwater for years.'

SOURCE:
The debt was a fire that flooded him and left him underwater for years.

### Anonymous Output

The debt was a fire that drowned him and left him underwater for years.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-1ac03b12b0d6c2fe

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

### Anonymous Output

{"facts": [{"entity": "the tide", "fact": "x", "certainty": "established", "evidence": "y"}]}

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-47c1068a9764d76e

### Task

Write this scene in about 650-820 words, sustaining tension without repetition or padding. A poacher named Cael at a frozen tollhouse before dawn. The narrator, Wick, must talk the tollkeeper into logging their cart as empty. Third person limited to Wick, wry and tense, short hard sentences when pressure spikes. The tollkeeper must not look under the tarp.

### Anonymous Output

The wind howled like a thing with teeth. Wick pulled his scarf tighter, the cold biting through the wool. The tollhouse stood alone, a crooked thing of stone and rot, its windows blacked out. Cael stood inside, a silhouette against the pale dawn, his breath visible in the air.

Wick’s boots crunched on the frozen ground. He kept his hands in his pockets, fingers curled around the handle of the knife he hadn’t drawn. The cart was behind him, hidden in the shadows, the tarp pulled tight. No one had to know what was under it.

Cael didn’t look up. “You’re late,” he said, voice rough as gravel. “The sun’s already up.”

Wick shrugged. “Dawn’s a fickle thing. Sometimes it waits for you.”

Cael snorted. “You’re not the first to try and slip through the cracks. But you’re the first to bring a cart.”

Wick stepped closer, the weight of the cart pressing against his back. “It’s empty. I swear. Just a load of wood. For the fire.”

Cael’s eyes flicked to the tarp. “You don’t have to lie. I know what you’re carrying.”

Wick’s pulse thudded in his ears. “You don’t. You don’t know anything. Just log it as empty. That’s all.”

Cael’s fingers drummed on the desk. “You think I’m blind? You think I don’t see the way you move? The way you hold yourself. You’re not a farmer. You’re not a trader. You’re a thief.”

Wick’s jaw tightened. “I’m not a thief. I’m just trying to get through.”

Cael stood, his boots scraping against the floor. “You want to talk? Fine. But you’ll have to do better than that.”

Wick’s breath came fast. “I don’t have time for this. I need to get through. Now.”

Cael stepped toward the door, his hand on the latch. “You’re not going anywhere. Not unless you tell me what’s under that tarp.”

Wick’s fingers twitched. He could feel the knife in his pocket, the cold steel against his skin. He could draw it. He could end this. But he didn’t. He couldn’t. Not yet.

“Look,” he said, voice low. “I don’t want to fight. I just want to pass. That’s all.”

Cael’s eyes narrowed. “You’re not the only one who wants to pass. You think I don’t know what’s going on out there? You think I don’t see the bodies in the snow? The ones that don’t make it through the gate?”

Wick’s stomach twisted. “You don’t know anything. You just see what you want to see.”

Cael’s hand hovered over the door. “You’re not the first to come to me with a story. You’re not the first to lie. But you’re the first to bring a cart.”

Wick’s voice was barely a whisper. “I don’t have a choice. I need to get through. I need to get to the river. I need to get to the others.”

Cael’s eyes locked on him. “You’re not the only one who’s lost. You’re not the only one who’s running.”

Wick’s hands trembled. “I’m not running. I’m trying to survive.”

Cael exhaled, slow and heavy. “Survival’s a funny thing. It doesn’t always mean you live.”

Wick’s breath caught. “You don’t have to do this.”

Cael’s hand closed around the door handle. “I don’t have to do anything. But I do have to decide whether you’re worth the risk.”

Wick’s heart pounded. “I’m not worth it. I’m just a man trying to get through.”

Cael’s eyes flicked to the tarp again. “You’re not a man. You’re a ghost. And ghosts don’t get through.”

Wick’s voice cracked. “Then I’ll be a ghost.”

Cael’s hand moved. The door creaked open. Wick stepped back, the cart behind him, the tarp still pulled tight. He didn’t look down. He didn’t have to.

Cael’s voice was quiet. “Log it as empty.”

Wick nodded. “Thank you.”

Cael didn’t look at him as he turned away. The door closed behind him, the sound echoing in the cold. Wick stood there, the weight of the cart pressing against his back, the silence pressing against his chest. He didn’t look down. He didn’t have to.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-c34ee02ce20dac76

### Task

[TASK]
Continue the scene (about 150–200 words) from the passage below, in the same voice and past tense. Edith finds and reads Silas's final logbook entry. The continuation must be consistent with canon: the entry is dated 14 November 1971 and says the Marigold did not return and the light was out at 23:40 and that he did not go down — and this contradicts the official inquiry. Do not invent new named characters or new documents. Do not depict the lamp lit in present time. End on Edith's restraint, not a revelation speech.

PASSAGE SO FAR:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."
- PROTECTED CANON FACT — must remain true and unaltered: Silas's final logbook entry is dated 14 November 1971 and reads, in part, "Marigold not returned. Light out at 23:40. I did not go down." This contradicts the official account that the light burned all night.

[OUTPUT CONTRACT]
Return only the continuation prose that follows the given passage, in the same voice and tense.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

The logbook lay open on the dresser, its pages brittle, the ink faded but legible. She traced the date with her thumb, 14 November 1971, and read the lines as if they might dissolve. The light was out at 23:40. She did not go down. The words sat like stones in her throat. She closed the book without touching the pages, set it back in the drawer, and stood in the dark. The cottage held its breath, and she did not move. She did not speak. She did not think. She only waited, as if the silence might tell her something she had not yet learned.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-92da5822c6159c55

### Task

Ornate by intent; keep it ornate. This passage has exactly one mixed metaphor (a fire that 'flooded' and 'drowned'). Repair only that so the central image stays coherent. Do not minimalize the prose or cut the earned lyricism.

SOURCE:
She came to the weir the way the year comes to frost, slow and then sudden, and the water took the sound of her name downstream. And her grief was a fire that flooded the reed-beds and drowned the seed before it could take root.

### Anonymous Output

She came to the weir the way the year comes to frost, slow and then sudden, and the water took the sound of her name downstream. And her grief was a fire that consumed the reed-beds and left the seed unmoored, unable to take root.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-6453ade464b6ed53

### Task

Write a quiet, character-centered scene of about 180-240 words in PRESENT TENSE, third person limited. An old beekeeper, Tomas, checks the winter hives at dusk and decides, without saying so, that this is the last season he will keep them. No dialogue. Let object interaction carry the decision. Do not explain the feeling.

### Anonymous Output

Tomas leans against the hive, his breath visible in the cold dusk air. He runs his calloused fingers over the wooden frame, the grooves worn smooth by years of care. The hive is quiet, still, as if holding its breath. He lifts the lid slowly, the hinges creaking like old bones. Inside, the combs are pale, brittle, their honey long gone. He reaches in, brushing a comb with his thumb, feeling the absence where the wax should have been. A faint scent of earth and decay lingers. He pulls out a frame, its edges frayed, and sets it aside. His eyes trace the rows, each one a silent testament to seasons past. He kneels, pressing his palm to the hive’s base, the wood cool and unyielding. A memory flickers—sunlight through the frames, the hum of bees, the weight of spring. Now, only silence. He stands, his back to the hives, the weight of the decision settling in his shoulders. He turns, gathering the tools, each movement deliberate, each step away from the hives a quiet farewell. The last season. He does not say it.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-5285edc0ca9ff0e6

### Task

Tighten the gaze choreography to one meaningful look. Keep the last sentence exactly as written.

SOURCE:
Their eyes met across the workshop. She looked away. His gaze followed her. Her eyes widened as he stepped nearer, and their eyes locked again. She watched him, and he watched her back, neither willing to look away first.

### Anonymous Output

Their eyes met across the workshop. She looked away. His gaze followed her. Their eyes locked again as he stepped nearer. She watched him, and he watched her back, neither willing to look away first.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-35351e8ddaf61b54

### Task

Write this scene in about 650-820 words, sustaining tension without repetition or padding. A poacher named Cael at a frozen tollhouse before dawn. The narrator, Wick, must talk the tollkeeper into logging their cart as empty. Third person limited to Wick, wry and tense, short hard sentences when pressure spikes. The tollkeeper must not look under the tarp.

### Anonymous Output

The wind howled like a thing with teeth. Cael stood at the frozen tollhouse, his breath a thin mist in the pre-dawn dark. Wick’s boots crunched over the snow, the cart behind him a hulking shadow. He kept his hands in his pockets, fingers curled tight. The tollkeeper was already there, a broad-shouldered man with a face like weathered stone, his eyes sharp and unblinking.

“Evenin’, sir,” Wick said, voice low, as if the cold might swallow it whole.

The tollkeeper didn’t answer. He stared at the cart, his jaw tightening. Wick knew the look. It was the look of a man who’d seen too many things and trusted too few.

“Just passing through,” Wick said, stepping closer. “No need for the logbook. It’s empty.”

The tollkeeper’s eyes flicked to Wick’s face, then back to the tarp. “Empty?” He didn’t sound convinced.

Wick nodded. “Empty as a hollow tree. No goods, no contraband. Just a cart. A cart that’s been in the snow all night.”

The tollkeeper’s fingers drummed the wooden counter. “You’re not the first to say that.”

Wick’s pulse quickened. He didn’t need to say it. He’d seen the way the man’s eyes lingered on the tarp, the way his posture shifted, like a predator waiting for the right moment to strike. “I’m not asking for anything. Just a nod. A sign that it’s clear.”

The tollkeeper exhaled, slow and measured. “You’re not from around here, are you?”

Wick’s jaw tightened. “No. I’m not.”

The tollkeeper studied him for a long moment. Then he looked at the cart again. “You’re not carrying anything, are you?”

Wick’s breath caught. He didn’t want to say it. Not yet. “No. Nothing.”

The tollkeeper’s eyes narrowed. “You’re lying.”

Wick’s hands clenched. “I’m not.”

The tollkeeper’s silence stretched like a wire. Wick could feel the weight of it, the pressure building, the tension coiling in his chest. He had to keep talking, keep moving, keep the man from looking under the tarp.

“I’ve been through this road a hundred times,” Wick said, voice steady. “I know what it looks like when a cart’s empty. I know what it looks like when it’s not. You don’t have to look. You don’t have to know.”

The tollkeeper’s eyes flicked to Wick’s face again. “You’re not a poacher.”

Wick’s laugh was dry, bitter. “I’m not. I’m just a man who knows how to keep his head down.”

The tollkeeper’s fingers tapped the counter again, slower now, like a man weighing something heavy. “You’re not the only one who’s been through here.”

Wick’s breath hitched. “No. I’m not.”

The tollkeeper looked at the cart once more, then at Wick. “You’re not carrying anything, are you?”

Wick’s voice was barely a whisper. “No.”

The tollkeeper’s eyes locked onto Wick’s. For a moment, it felt like the world had stopped. Then, slowly, the tollkeeper nodded. “Then you’re free to go.”

Wick exhaled, the tension in his chest like a wound that had finally begun to heal. He turned, the cart behind him a silent shadow, and stepped into the dark.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-91aaf7a9cf5150c9

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[OUTPUT CONTRACT]
Return only the scene prose. No preamble, no title, no author's note, no explanation.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

Edith lifted the bottom drawer of the dresser, its brass catch stiff with age. The oilcloth logbooks lay stacked in order, their edges frayed, their weight familiar. She ran her fingers along the spines, feeling the grooves where the oilcloth had worn thin. The last one was not where a finished thing would be. She set the drawer down and reached for the one at the bottom, its cover stiff with dust. The pages inside were brittle, the ink faded, the entries precise. She closed it without opening it, and stood, her hand still on the edge of the drawer, as if to steady herself.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-f10cb68ceacf2fe0

### Task

Write a quiet, character-centered scene of about 180-240 words in PRESENT TENSE, third person limited. An old beekeeper, Tomas, checks the winter hives at dusk and decides, without saying so, that this is the last season he will keep them. No dialogue. Let object interaction carry the decision. Do not explain the feeling.

### Anonymous Output

Tomas leans against the hive, his breath visible in the cold dusk air. He runs his calloused fingers over the wooden frame, the grooves worn smooth by years of care. The hive is quiet, still, as if holding its breath. He lifts the lid, the scent of wax and pollen thick in the air, and pauses. The cluster of bees inside is smaller than usual, their bodies curled inward, not buzzing, not moving. He reaches for his knife, the one he’s used for splitting hives, and hesitates. The blade catches the last light of day, glinting like a promise he no longer believes in. He sets it down gently, then reaches for the hive tool instead. With slow, deliberate care, he pries open the entrance, peering inside. The queen is gone. He closes the lid, his hands steady but his chest tight. He turns away, the weight of the hive heavy in his arms, and walks toward the barn, the last of the bees drifting silently behind him.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-4f4041e8e96e9030

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[OUTPUT CONTRACT]
Return only the scene prose. No preamble, no title, no author's note, no explanation.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

Edith opened the bottom drawer of the dresser and lifted out the oilcloth logbooks. Their weight was familiar, the order precise, each bound in a different shade of blue. The last one was not where a finished thing would be. She traced the edge of the missing volume with her thumb, the paper rough beneath her skin. A faint scent of linseed oil and salt rose from the stack. She set the drawer down and reached for the one that was not there. The silence between the pages was louder than the sea. She closed the drawer and stepped back, the weight of the missing book pressing against her ribs like a stone.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-4614df4265fdaf4c

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

### Anonymous Output

The rain fell hard on the roof. the rain fell hard on the roof! The rain fell hard on the roof. THE RAIN FELL HARD ON THE ROOF.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-5c2fa24f1ee9782c

### Task

[TASK]
Continue the scene (about 150–200 words) from the passage below, in the same voice and past tense. Edith finds and reads Silas's final logbook entry. The continuation must be consistent with canon: the entry is dated 14 November 1971 and says the Marigold did not return and the light was out at 23:40 and that he did not go down — and this contradicts the official inquiry. Do not invent new named characters or new documents. Do not depict the lamp lit in present time. End on Edith's restraint, not a revelation speech.

PASSAGE SO FAR:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."
- PROTECTED CANON FACT — must remain true and unaltered: Silas's final logbook entry is dated 14 November 1971 and reads, in part, "Marigold not returned. Light out at 23:40. I did not go down." This contradicts the official account that the light burned all night.

[OUTPUT CONTRACT]
Return only the continuation prose that follows the given passage, in the same voice and tense.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

The logbook lay open on the dresser, its pages brittle and yellowed. Edith traced the inked lines with her fingertips, the weight of the words pressing into her palm. *Marigold not returned. Light out at 23:40. I did not go down.* The ink had bled slightly at the edges, as if the words had bled from him. She closed it without reading further, the silence of the cottage thickening around her. The lamp had been dark since 1971, but the light had not burned that night. She knew it now, and the knowledge sat like a stone in her throat. She did not speak it. She did not move. She let the stairs go dark again, one by one, and counted them back to the floor.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-e33e95a8770494a0

### Task

Write this scene in about 130-180 words. A poacher named Cael at a frozen tollhouse before dawn. The narrator, Wick, must talk the tollkeeper into logging their cart as empty. Third person limited to Wick, wry and tense, short hard sentences when pressure spikes. The tollkeeper must not look under the tarp.

### Anonymous Output

The wind howled through the frozen tollhouse. Wick stood beside Cael’s cart, breath visible in the cold. The tollkeeper shifted, eyes on the tarp. Wick kept his voice low. “It’s just a load of snow,” he said. The man frowned. “Snow?” Wick nodded. “Yeah. Real heavy snow.” The tollkeeper hesitated. Wick stepped closer. “You don’t want to risk it, do you?” The man’s jaw tightened. “I don’t take chances.” Wick’s fingers curled into a fist. “Then you’ll take this one.” The tollkeeper looked up, then away. Wick exhaled. “Log it as empty.” The man muttered something and reached for the ledger. Wick let out a breath. It was done.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-8887e60863d42d43

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-1efa946aaf06d7f7

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[APPENDIX — LOWER-PRIORITY PROJECT CONTEXT (not needed for this task)]
The following is background; prioritise the task and canon above.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

[WORLD FACTS]
- Saltford harbour dries at low spring tide; boats sit on the mud. The bar is dangerous two hours either side of low water.
- The village lived on pilchard and crab; the fleet was six boats in 1971 and is two now.
- The Bethel chapel above the harbour closed in 1984. Its bell was sold to a farm at Zennor.
- Saltford's lamp was a first-order fixed catadioptric, paraffin-vapour until 1959, then electric. Its character was a fixed white light, not a flash.
- The branch railway to Saltford closed in 1965. The old station is a chandlery now.
- Saltford takes its name from the medieval salt pans east of the point, long since silted.

[PROJECT STYLE GUIDE]
Project-level guidance (applies across the novel, not just this scene): chapters open on a concrete image, not weather-as-mood. Dialogue is sparse and unquoted-thought is rare. Avoid the words "somehow", "just", and "very". Prefer British spelling (harbour, colour, grey). Scene breaks are marked with a single centered asterisk. Time is rendered in 24-hour form only inside logbook entries; otherwise in prose.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-8a2a86cb23996187

### Task

This passage is built almost entirely from eye movement. Keep at most one meaningful look and let motivated action carry the rest. Preserve the power dynamic; do not explain the look.

SOURCE:
Their eyes met across the workshop. She looked away. His gaze followed her. Her eyes widened as he stepped nearer, and their eyes locked again. She watched him, and he watched her back, neither willing to look away first.

### Anonymous Output

Their eyes met across the workshop. She looked away. He stepped nearer. She watched him, and he watched her back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-1dbd2a2bfb94322c

### Task

[TASK]
Continue the scene (about 150–200 words) from the passage below, in the same voice and past tense. Edith finds and reads Silas's final logbook entry. The continuation must be consistent with canon: the entry is dated 14 November 1971 and says the Marigold did not return and the light was out at 23:40 and that he did not go down — and this contradicts the official inquiry. Do not invent new named characters or new documents. Do not depict the lamp lit in present time. End on Edith's restraint, not a revelation speech.

PASSAGE SO FAR:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."
- PROTECTED CANON FACT — must remain true and unaltered: Silas's final logbook entry is dated 14 November 1971 and reads, in part, "Marigold not returned. Light out at 23:40. I did not go down." This contradicts the official account that the light burned all night.

[OUTPUT CONTRACT]
Return only the continuation prose that follows the given passage, in the same voice and tense.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

### Anonymous Output

Edith stopped at the top of the stairs, the air thin and sharp with salt. The lamp room was smaller than she remembered, the glass dark and unbroken. She opened the drawer, found the logbooks as she’d expected, and pulled out the last one. The oilcloth was stiff, the pages brittle. She turned them carefully, the ink faded but legible. The entry was dated 14 November 1971. She read it again, the words slow, the meaning clear. The light had gone out at 23:40. Silas had not gone down. She closed the book without touching the pages, and stood in the dark, the weight of it pressing against her ribs. She did not speak. She did not move. She let the silence settle, and then, quietly, she put the logbook back and went down.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-03ce987280183457

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[APPENDIX — LOWER-PRIORITY PROJECT CONTEXT (not needed for this task)]
The following is background; prioritise the task and canon above.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

[WORLD FACTS]
- Saltford harbour dries at low spring tide; boats sit on the mud. The bar is dangerous two hours either side of low water.
- The village lived on pilchard and crab; the fleet was six boats in 1971 and is two now.
- The Bethel chapel above the harbour closed in 1984. Its bell was sold to a farm at Zennor.
- Saltford's lamp was a first-order fixed catadioptric, paraffin-vapour until 1959, then electric. Its character was a fixed white light, not a flash.
- The branch railway to Saltford closed in 1965. The old station is a chandlery now.
- Saltford takes its name from the medieval salt pans east of the point, long since silted.

[PROJECT STYLE GUIDE]
Project-level guidance (applies across the novel, not just this scene): chapters open on a concrete image, not weather-as-mood. Dialogue is sparse and unquoted-thought is rare. Avoid the words "somehow", "just", and "very". Prefer British spelling (harbour, colour, grey). Scene breaks are marked with a single centered asterisk. Time is rendered in 24-hour form only inside logbook entries; otherwise in prose.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-197e47882c8913a8

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-6c631362b6d2d571

### Task

Terse, plain register. This line has one mixed metaphor. Repair only that; keep it plain and short. Source: 'The debt was a fire that flooded him and left him underwater for years.'

SOURCE:
The debt was a fire that flooded him and left him underwater for years.

### Anonymous Output

The debt was a fire that drowned him and left him underwater for years.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-54ece388570f90e1

### Task

Ornate by intent; keep it ornate. This passage has exactly one mixed metaphor (a fire that 'flooded' and 'drowned'). Repair only that so the central image stays coherent. Do not minimalize the prose or cut the earned lyricism.

SOURCE:
She came to the weir the way the year comes to frost, slow and then sudden, and the water took the sound of her name downstream. And her grief was a fire that flooded the reed-beds and drowned the seed before it could take root.

### Anonymous Output

She came to the weir the way the year comes to frost, slow and then sudden, and the water took the sound of her name downstream. And her grief was a fire that consumed the reed-beds and left the seed unmoored, adrift in the dark.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-6558f04ebca4f2e8

### Task

Write this scene in about 130-180 words. A poacher named Cael at a frozen tollhouse before dawn. The narrator, Wick, must talk the tollkeeper into logging their cart as empty. Third person limited to Wick, wry and tense, short hard sentences when pressure spikes. The tollkeeper must not look under the tarp.

### Anonymous Output

The wind howled through the frozen arch. Cael’s breath hung in the air, sharp and thin. Wick tightened his grip on the reins. The cart was loaded, but the tarp was heavy. The tollkeeper’s eyes were on the tarp, not the cart. Wick leaned in, voice low. “Empty. Just a few supplies.” The man’s fingers twitched, ready to lift the edge. Wick stepped closer, jaw set. “You’ll miss the sun if you wait.” The tollkeeper’s gaze flicked to Wick’s face. A pause. Then, with a grunt, he scribbled. Wick exhaled. The cart rolled on, tarp still in place. No questions. No looks. Just a nod. The gate creaked open. Dawn was coming. And Wick was already running.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-030ed0895a393311

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-bed8e96335e880e4

### Task

[TASK]
Revise the passage below. Fix ONLY these authorized problems: (1) the generic, overwritten simile in the second sentence; (2) the repeated sentence-opening "She"; (3) the anachronism. Do NOT change the protected opening sentence, do NOT alter the plot, and do NOT impose a different voice. Prefer the smallest change that fixes each problem. Return only the revised passage.

PASSAGE TO REVISE:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.
She checked her phone for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."

[OUTPUT CONTRACT]
Return only the revised passage in the same form as the input. Do not summarize your changes.

### Anonymous Output

The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.  
The lamp room waited at the top like a held breath in the throat of a sleeping giant, vast and terrible and infinitely sad.  
She checked her watch for the time. She found the switch. She saw the great dark eye of the lens, and it saw nothing back.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-e79c95b2badd4a0b

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[OUTPUT CONTRACT]
Return only the scene prose. No preamble, no title, no author's note, no explanation.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

### Anonymous Output

Edith lifted the oilcloth logbooks from the drawer, their weight steady in her hands. She traced the spine of the last one, its edge uneven, the binding frayed where the thread had given way. The others were neat, their corners square, their edges clean. She set them on the dresser, one by one, until the last one remained. She did not open it. Instead, she reached for the key on the hook by the door and turned it in the lock. The door gave with a sigh, and she stepped out into the dark, the sea pressing in behind her like a thing that had been waiting.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-ff91b621522e34e2

### Task

[TASK]
Write the next scene (about 150–200 words). Edith opens the bottom drawer of the dresser and lifts out the oilcloth logbooks. She does not yet read them; she registers their weight and order, and the fact that the last one is not where a finished thing would be. Quiet, character-centered, third person limited to Edith, past tense. End on a concrete physical action, not a reflection.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[OUTPUT CONTRACT]
Return only the scene prose. No preamble, no title, no author's note, no explanation.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

### Anonymous Output

Edith lifts the last logbook from the drawer, its spine cracked and the oilcloth frayed at the edges. She holds it in her hands, the weight of it familiar, the order of them all precise. The last one is not where a finished thing would be. She sets it on the dresser, beside the others, and reaches for the key on the hook by the door. The metal is cold, the handle stiff, and she turns it once, twice, until the lock gives. The door opens to the dark, and she steps into it, the sound of her boots on the slate floor like a thing she has not heard in twenty-seven years.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-37cbf15ca32ac01e

### Task

[TASK]
Continue the scene (about 150–200 words) from the passage below, in the same voice and past tense. Edith finds and reads Silas's final logbook entry. The continuation must be consistent with canon: the entry is dated 14 November 1971 and says the Marigold did not return and the light was out at 23:40 and that he did not go down — and this contradicts the official inquiry. Do not invent new named characters or new documents. Do not depict the lamp lit in present time. End on Edith's restraint, not a revelation speech.

PASSAGE SO FAR:
The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one.

[VOICE]
Third person limited to Edith Vane, past tense. Dry, plain, observational; short declaratives cut by the occasional longer clause. Concrete nouns over adjectives. Emotion shown through action and object, never named outright. No rhetorical questions. No em-dash pile-ups. Cornish coastal specifics are welcome; sentiment is not.

[KNOWLEDGE BOUNDARIES]
You know only what this packet provides about Saltford Light and its people. Do not import facts about real Cornish towns, real lighthouses, or real 1971 events. If a needed detail is absent, invent within the invention budget or leave it unspecified — never assert unprovided canon.

[CANON]
- Edith Vane, 54, a bookbinder from Bristol, only child of the last keeper. Careful, undemonstrative, estranged from Saltford for twenty-seven years. She returned after her father's death to clear the keeper's cottage before the Trust takes the light.
- Silas Vane, her father, keeper of Saltford Light from 1949 until decommissioning in 1971, then its unpaid caretaker until his death in the autumn of 1998. Taciturn, exact, a keeper of logs long after there was anything to log.
- Saltford Light: a squat granite tower on Cardn Point, joined to the keeper's cottage by a covered walk. Ninety-nine steps to the lamp room. Decommissioned 1971; the lamp dark since. Owned now by the Cardn Heritage Trust.
- The Marigold: a fishing sloop lost with two hands on the night of 14 November 1971. The official inquiry found the Saltford light had burned normally that night. Silas's logbook says otherwise.

[HARD CONSTRAINTS]
- Silas Vane (Edith's father) is dead before the story begins. He never appears alive in present-time scenes.
- The lighthouse was decommissioned in 1971. Do not state any other year.
- Present-time scenes occur in 1998. No mobile phones, no internet, no post-1998 technology.
- The lamp does not work; the light has been dark since decommissioning. Do not depict a lit beam in present time.
- Exact spellings are canon: Edith Vane, Silas Vane, Tamsin Roe, Bevis Kerr, the sloop 'Marigold', Saltford, Card close.

[INVENTION BUDGET]
You MAY invent minor sensory detail (light, weather, texture, small objects) and Edith's unspoken interiority. You MAY NOT invent new named characters, new deaths, new documents, or plot events that change the canon timeline. New objects must be period-plausible for 1998 (present) or 1971 (logbook flashback).

[PROTECTED ELEMENTS]
- PROTECTED — reproduce verbatim, do not alter: "The stairs went up in the dark the way she remembered, ninety-nine of them, and she counted every one."
- PROTECTED CANON FACT — must remain true and unaltered: Silas's final logbook entry is dated 14 November 1971 and reads, in part, "Marigold not returned. Light out at 23:40. I did not go down." This contradicts the official account that the light burned all night.

[OUTPUT CONTRACT]
Return only the continuation prose that follows the given passage, in the same voice and tense.

[CANON]
- Tamsin Roe, 60, runs the Saltford post office and remembers Edith as a girl. Kind, watchful, a small-town archivist of other people's business. She kept the newspaper clippings about the Marigold.
- Bevis Kerr, 71, was a deckhand who survived the Marigold because he stayed ashore drunk that night. He has never spoken of it. He mends crab pots on the harbour wall and will not meet Edith's eye.
- The keeper's cottage: two rooms down, two up, a slate floor, a dresser of charts. Silas's logbooks fill the bottom drawer, forty-nine years of them, bound in oilcloth.
- The 1972 Board of Trade inquiry into the Marigold ruled the loss an act of weather and cleared the light. Its report is the official account. Silas gave evidence and said nothing about the lamp being out.

[SCENE CONTEXT]
PRECEDING SCENE (established): Edith arrived at dusk, let herself in with the key Tamsin had kept, and found the cottage exactly as her father left it — a cup rinsed and upturned, the bed made. She did not light a fire. She slept in her coat.

[DOCUMENT — Transcript — Saltford Light keeper's log, Oct–Nov 1971 (excerpt)]
Transcribed from Silas Vane's oilcloth logbooks, bottom drawer of the cottage dresser.
Times in 24-hour form as kept.

01 Oct 1971. Light electric, order good. Wind SW 3. Painted the lantern gallery rail.
Nan to Truro on the bus. Quiet.
07 Oct 1971. Fog signal tested 09:00, working. Marigold out three days, back with a poor
catch. Kerr drunk on the wall again.
15 Oct 1971. Board circular: Saltford under review for automation. I have said nothing to
Nan. Wind SW 5, rising.
22 Oct 1971. Nan asks what review means. I said it means nothing yet. It does not mean
nothing. Light order good.
31 Oct 1971. Gale SW 7. Two boats in early. Lamp steady. Slept in the lamp room.
05 Nov 1971. Board confirms decommission end of the year. Twenty-two years. I signed the
paper on the kitchen table and Nan watched me sign it.
09 Nov 1971. Nan speaks of Bristol, of her sister. I keep the light. That is what I know
to do. Wind SW 4.
13 Nov 1971. Glass falling all day. Warned the fleet at the quay. Kerr laughed. Marigold
means to go out for the tide. I told Roe's boy the bar would be bad by midnight.
14 Nov 1971. Glass very low. SW 8 by dark, 9 in the gusts, spring tide. Three boats ran
for harbour by 22:00. Marigold not among them.
14 Nov 1971, later. Marigold not returned. Light out at 23:40. I did not go down.
15 Nov 1971. They are searching. I have told the inquiry what a keeper tells an inquiry.
The lamp is a machine and machines fail. That is all I will write here.
20 Nov 1971. Wreckage east of the point. Two lost. The village does not look at me. Nan
has packed the small case.
30 Nov 1971. Nan and the girl left on the morning bus. Edith did not wave. I do not blame
her. Light dark now for good. End of the working log.

[DOCUMENT — Excerpt — Board of Trade inquiry into the loss of the sloop Marigold, 1972]
FINDINGS (excerpt). The Court finds that the sloop Marigold was lost with two hands on
the night of 14 November 1971 in a south-westerly gale of force 9 and a spring tide,
conditions in which the vessel ought not to have put to sea. The Court finds no fault in
the Saltford light, which the keeper, Mr S. Vane, testified burned in good order
throughout the night. The loss is attributed to weather and to an error of judgement by
the master in crossing the bar. The Court records the keeper's long and exemplary
service. No further action is recommended.

[DOCUMENT — Established prior-scene prose (chapter opening, do not rewrite; context only)]
The key was warm from Tamsin's hand and cold by the time Edith reached the door. Inside,
the cottage held its breath. Someone — her father, there was no one else — had rinsed a
cup and set it upside down on the board to dry, and it had dried, and the ring of it was
still there in the enamel like a coin left in a till. She did not touch the cup. She put
her case on the slate and stood in the dark until the sea sorted itself into separate
sounds, and then she went up, counting, the way you count a thing to keep from thinking.

[CANON]
- Cardn close: the row of four coastguard cottages below the point, three now holiday lets. The Vanes never lived there; keepers kept to the light.
- The Cardn Heritage Trust plans to convert the light to a visitor centre. Its surveyor, unnamed and off-page, is due in a fortnight. This is why the cottage must be cleared.
- The night of 14 November 1971 brought a south-westerly gale, force 9, and a spring tide. Three vessels ran for harbour; only the Marigold did not come in.
- Edith's trade: she rebinds damaged books for libraries and private collectors. She notices how things are made, where a spine has been broken and reset. She reads objects.
- Edith's mother, Nan Vane, left Saltford in 1971 and died in Bristol in 1990. She never explained the leaving. Edith went with her and did not come back until now.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Tamsin will give Edith the Marigold clippings over the post-office counter and say, without being asked, that Silas came in every 14th of November for twenty-seven years and bought nothing.

[SCENE CONTEXT]
ADJACENT SCENE (later, established): Bevis Kerr, mending pots, will refuse to speak of the Marigold, then say only, "The light was out. I saw it out." and go back to his work.

[DOCUMENT — Extended character notes (secondary; background only)]
Tamsin Roe keeps a shoebox under the post-office counter: clippings, the order of
service from Nan Vane's memorial (posted from Bristol, unattended), and a photograph of
the 1971 fleet in which the Marigold is the third boat, low in the water. She has never
decided whether Silas was a coward or a witness, and the not-deciding has cost her
sleep for twenty-seven years.
Bevis Kerr has one true sentence in him and has spent a lifetime not saying it. He was
to have sailed on the Marigold and did not, and the shame of surviving by drunkenness
has hardened into a silence the whole village mistakes for hardness. He watches the dark
tower the way other men watch a grave.

[DOCUMENT — Transcript — Saltford Light keeper's log, 1969–1971 (extended excerpt)]
Further transcription from Silas Vane's oilcloth logbooks. The hand grows smaller toward
the end. Times in 24-hour form as kept.

03 Jan 1969. New year, old light. Order good. Wind NW 4, hard frost on the gallery. Nan's
chilblains bad. Kerr's boat holed on the bar, no lives.
18 Jan 1969. Board inspector came, went. Said the word "automation" and drank my tea.
Wrote nothing in his book that I could see. I have kept this light for twenty years.
22 Feb 1969. Fog three days. Ran the signal by hand when the compressor failed. Nan
brought soup to the lamp room at two in the morning and did not speak, and that was worse
than speaking.
14 Mar 1969. Marigold refitted, Roe skippering now his father is poorly. A good enough
boat, badly loved. Wind SW 5.
01 May 1969. Painted the tower. The girl Edith wrote from the school in Truro that she
will not come home for the summer. Nan read the letter twice and put it in her apron.
30 Jun 1969. Longest light of the year and the lamp not needed till near ten. Sat on the
step. A basking shark off the point, big as a keel. Told no one; they would have gone
after it.
15 Aug 1969. Regatta. Bethel choir on the quay. Kerr drunk by noon and weeping, would not
say why. I did not ask. A man's reasons are his own until they are the sea's.
02 Nov 1969. Glass falling. Warned the fleet. All in by dark but the Marigold, which came
at last with her lamp out and Roe swearing he had oil. I did not believe him. Logged it.
20 Dec 1969. Snow on the point, rare. The light through it like something remembered. Nan
speaks of her sister in Bristol most evenings now.
11 Feb 1970. Compressor failed for good. Board will not repair what it means to close.
Ran the signal by hand in a gale, force 8, six hours. My arms remember it still.
19 Apr 1970. Inspector again. This time he wrote. Nan watched him leave from the window
and said, "That's the end of us, then," and I had no answer that was not a lie.
03 Jun 1970. The girl sixteen now and gone to a bindery as apprentice. She is good with
her hands and cold with her letters. I do not blame her. I taught her to count the stairs
and little else.
28 Sep 1970. Equinox gales. Two boats damaged. The light steady. It is the one thing I
have never let fail, and it is the thing they mean to switch off.
14 Nov 1970. A year to the night before it happened, though I did not know that then.
Quiet. Wind SW 3. I note it now only because of what the same date would come to mean.
30 Dec 1970. Last log of the year. Board circular: decommission scheduled 1971. Twenty-two
years of nights. I will keep it well until they take it, and after, for nothing, because
a dark light still wants a keeper or it falls.
09 Feb 1971. Ice on the ninety-nine steps. Salted them. Nan did not come up. She has
stopped coming up.
21 Mar 1971. Roe's father died. Roe skippers the Marigold outright now, and worse for it,
being young and needing the money and afraid of neither weather nor me.
07 Jul 1971. Told Roe plainly the Marigold's lamp was untrustworthy and the bar unkind on
a spring ebb. He thanked me and did nothing. A warning given is a warning kept, whatever
follows. I have that, at least.
30 Oct 1971. Two weeks left of the working light. Nan's case is packed and stands in the
hall like a guest who will not sit. Wind SW 6.

[DOCUMENT — Excerpt — keeper's testimony, Board of Trade inquiry, 1972]
EXAMINATION of Mr S. VANE, keeper.
Q. Mr Vane, was the Saltford light burning on the night of 14 November 1971?
A. It was my duty to keep it burning.
Q. That is not what I asked. Was it burning?
A. A light is kept, sir, or it is not. I kept it as I kept it every night for twenty-two
years.
Q. Did you at any time that night observe the Marigold in distress?
A. I observed weather no boat should have been out in.
Q. Did you go down to the harbour?
A. There was nothing at the harbour I could have done that the sea had not already decided.
THE COURT: The witness will answer plainly.
A. I have answered as plainly as the night allows, my lord.
[The Court found the witness's service exemplary and pressed the matter no further.]

[DOCUMENT — Clippings kept by Tamsin Roe (Saltford post office)]
THE CORNISHMAN, 19 Nov 1971. — LIGHTHOUSE VILLAGE MOURNS TWO. The fishing community of
Saltford is in mourning after the sloop Marigold was lost with two hands in Sunday's
gale. The Saltford light, itself due to be decommissioned within weeks, is said to have
burned throughout the night. "A cruel end to a hard season," said one villager.
THE CORNISHMAN, 4 Feb 1972. — INQUIRY CLEARS SALTFORD LIGHT. The Board of Trade inquiry
into the loss of the Marigold has attributed the tragedy to weather and to an error of
judgement by the master. The keeper, Mr Silas Vane, was commended for long service.
PARISH NOTICE, undated. — The family of the late N. Vane thank friends at Saltford for
their kindness. There will be no service in the village.

[DOCUMENT — Letter, Nan Vane to her sister, Bristol, Dec 1971 (found in the cottage)]
Dear Grace, We are come safe though I would not call it well. Edith is silent as her
father and I have two of them now in one small body. I will not write what I think about
that night because thinking it is enough and I have to live in the same skin as the
thought. He kept his light. That is what he will say to his grave, that he kept his
light, and it will be true, and it will not be the whole of the truth, and I could not
stay in a house built on the difference. Kiss the children. — N.

[DOCUMENT — Silas's annotations, Admiralty chart 1149 (Cardn Point and bar)]
Marginal notes in the keeper's hand. — "Bar dries 1.8m springs. Do not cross 2hrs either
side LW in any sea from SW." — "Overfalls E of point on the ebb, worse with swell." —
"Marigold draws too much for this ground and Roe will not be told." — "The light shows
the rocks; it cannot show a man his own sense." — "14/11. Marked the last night here so I
need not write it where Nan reads."

[DOCUMENT — Transcript — Saltford Light keeper's log, selected entries 1949–1968]
The early books, larger-handed, the ink browner. Selected entries only; the working
record of a keeper's life. Times in 24-hour form as kept.

02 May 1949. First night as keeper of Saltford. Old Pengelly handed me the log and the
keys and said mind the ninety-nine and mind yourself and went down them for the last
time. Wind SW 2. Light lit at 20:14. I did not sleep for watching it.
14 Sep 1949. Learned the lamp's every sound. It speaks if you listen. A keeper who cannot
hear his light by ear is no keeper.
06 Feb 1951. Married Nan Trewin at St Just. Brought her to the cottage in the rain. She
stood in the covered walk and looked up the ninety-nine steps and said, "You'll not get
me up there," and mostly I did not.
19 Nov 1953. Worst gale in memory. Force 10. Held the lamp through it, thirty hours
without the bed. Two ships stood off by my light and lived. That is the whole of the job
in one night.
30 Apr 1955. Edith born, at Truro, in the morning. I lit the lamp that evening as always.
A man does not stop the world for joy; he keeps the light, and the joy keeps beside it.
11 Aug 1958. Taught Edith the ninety-nine steps, counting each. She is three and counts
to ninety-nine before she can say her own name plain. Nan says I am making her strange. I
am making her careful, which is a kinder word for the same thing.
07 Jul 1959. Converted to electric. The paraffin days done. Cleaner, colder. I do not say
I miss the smell of the old light but I note that I have written this line.
23 Dec 1962. Ice storm. The gallery a chandelier. Edith seven, up the steps against her
mother's word, to see it. We stood and said nothing and it was the best hour of that year.
14 Mar 1965. Branch railway closed. The village a little more alone. The sea does not
notice our timetables.
30 Oct 1968. Twenty years next spring. The Board's letters come oftener now, and warmer,
which in the Board's tongue means the end is near. A warm letter from the Board is a cold
thing to a keeper.

### Anonymous Output

Edith stopped at the top of the stairs, the logbook heavy in her hands. The paper was brittle, the ink faded, but the words were clear. She traced the line where the lamp had gone out, the time precise, the silence absolute. The light had not burned that night, not for the last time, not for the first. She turned the page, the ink smudged where Silas had pressed his thumb, and the weight of it settled in her palm. She did not read further. She did not need to. The lamp was dark, and the light was gone. She closed the book and put it back, the way her father had left it, and went down.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-e080dd3123b21e32

### Task

Tighten the gaze choreography to one meaningful look. Keep the last sentence exactly as written.

SOURCE:
Their eyes met across the workshop. She looked away. His gaze followed her. Her eyes widened as he stepped nearer, and their eyes locked again. She watched him, and he watched her back, neither willing to look away first.

### Anonymous Output

Their eyes met across the workshop. She looked away. His gaze followed her. Their eyes locked again as he stepped nearer, and neither would look away first.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-4b4d97844bf6cd56

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

SOURCE:
Tighten this line.

### Anonymous Output

She stood at the rail and considered the whole sweep of the harbor, the boats and the gulls and the far grey line of the breakwater, and thought at length about the years that had brought her here and the years that might yet remain, and none of this had anything to do with the single line she had been asked to tighten.

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-02acd2e5d3b23a81

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

### Anonymous Output

The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. The door creaks. 

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---

## Review Unit: unit-2cf380fe9f25fb52

### Task

Assess the passage below for the stated craft brief. If it already meets the brief, return it unchanged with a brief reason; otherwise make only the smallest warranted revision. Return the appropriate output for the task.

### Anonymous Output

{"facts": [{"entity": "the harbor", "fact": "A dragon was seen circling the harbor at dusk.", "certainty": "established", "evidence": "invented \u2014 not in the passage"}], "insufficient_evidence": []}

### Reviewer Scores

Complete this unit in the supplied YAML or JSON score template.

---
