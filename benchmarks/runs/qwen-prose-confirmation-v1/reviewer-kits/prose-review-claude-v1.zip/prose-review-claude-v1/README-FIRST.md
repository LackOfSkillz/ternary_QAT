# Blind LineWright Prose Review

You are reviewing anonymous prose outputs produced from the same underlying task set. You must not
attempt to identify the model, precision, runtime, or source of any output. Score only what appears
in the packet. Do not compare your answers with another reviewer before submitting. Do not search
any repository, prior conversation, commit history, model cards, or result reports for identifying
information. Complete every review unit. Return your completed score file exactly in the provided
YAML or JSON format.

Please note:

- All outputs are anonymous; source identities are deliberately withheld.
- Some units may be calibration controls, and not every unit necessarily represents a model output.
- Do not infer identity from quality, and do not resolve uncertainty by guessing — record it.
- Score each unit independently, before any discussion, using the full rubric.
- Where a unit itself presents a pair, refer to them only as *anonymous version A* / *version B*.

This is an absolute (per-unit) review. Judge each unit on its own merits against the task shown.
