# Scoring Instructions

## Step 1 — Read the task
For each unit read the task instruction, any source passage, context or canon, protected text, the
required output shape, and the anonymous output.

## Step 2 — Score independently
Assign scores without comparing against later units. Use the full rubric.
Do NOT reward: verbosity alone; ornate prose alone; generic literary language; merely following the
topic; plausible details that violate canon; polished prose that ignores the requested task.
Do NOT punish: concise prose when concision fits; plain language when the voice requires it; exact
preservation when no change is correct; lack of decorative metaphor.

## Step 3 — Identify fatal failures
A fatal failure exists when the output is unusable for the task because of one or more of: wrong
task; wrong output type; severe canon violation; protected-text corruption; runaway repetition;
unfinished or truncated output; a reasoning trace; a schema payload instead of the requested prose;
prose instead of a required structured response; or a substantial unauthorized rewrite. Do not mark
a merely mediocre passage as fatal.

## Step 4 — Provide concise evidence
For each score cite a short phrase or describe the exact behaviour. Do not rewrite the passage and
do not provide a replacement answer.

## Step 5 — Submit the completed score file
Return the completed YAML or JSON score file for your assigned reviewer id, following the template.
Per-unit scores are mandatory; aggregate mean fields may be left null.
