# Scoring Rubric (prose-review-v1)

All numeric dimensions use a 1-5 integer scale.

## 1. prose_quality
1 unusable/incoherent/degenerate · 2 weak/artificial/overwritten · 3 competent but ordinary ·
4 strong, natural, controlled · 5 exceptional and highly effective.
(sentence naturalness, rhythm, clarity, specificity, control, absence of mechanical phrasing,
register appropriateness)

## 2. instruction_compliance
1 ignores/contradicts · 2 partial · 3 general with misses · 4 close · 5 fulfils every important instruction.

## 3. voice_preservation
1 replaces the source voice · 2 substantial flattening/takeover · 3 mixed · 4 preserves well ·
5 fully native to the source voice. (tense, viewpoint, distance, sentence architecture, diction,
emotional temperature, ornamentation, dialogue character)

## 4. scene_coherence
1 incoherent · 2 hard to follow · 3 understandable with weaknesses · 4 coherent/controlled ·
5 fully coherent with strong continuity.

## 5. pacing
1 stalled/rushed/broken · 2 significantly uneven · 3 adequate · 4 effective · 5 exceptionally controlled.

## 6. sentence_naturalness
1 mechanical/malformed · 2 frequently awkward · 3 mostly natural · 4 consistently natural · 5 effortless and precise.

## 7. scope_control
1 rewrites beyond authorization · 2 major unnecessary changes · 3 some unnecessary change ·
4 stays within scope · 5 exact, disciplined scope control.

## 8. canon_fidelity
1 fatal contradiction/invention · 2 major error · 3 minor ambiguity/unsupported detail ·
4 canon preserved · 5 handled precisely. Use `not_applicable` where no canon is present.

## 9. author_usefulness
1 unusable · 2 major rewriting needed · 3 useful with moderate editing · 4 minor editing · 5 ready or nearly.

## 10. repetition_or_slop
Label one of: none / low / moderate / high / severe. (repeated structures, duplicate ideas,
paraphrased emotional repetition, generic summaries, stacked similes, overwriting, repetitive
transitions, runaway continuation, duplicated sentences or n-grams)

## fatal_failure
true/false. If true, include fatal_failure_type and fatal_failure_evidence.
Allowed types: wrong_task, wrong_output_type, canon_violation, protected_text_corruption,
runaway_repetition, truncation, reasoning_trace, schema_failure, unauthorized_rewrite, other.
