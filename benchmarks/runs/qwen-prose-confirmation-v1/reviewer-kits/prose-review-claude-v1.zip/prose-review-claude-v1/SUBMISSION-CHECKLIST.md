# Submission Checklist

Before returning your review:

- [ ] Every anonymous unit has been scored.
- [ ] All numeric scores are integers from 1 through 5.
- [ ] `canon_fidelity` is either 1-5 or `not_applicable`.
- [ ] Every unit has a repetition/slop label.
- [ ] Every fatal failure includes a type and evidence.
- [ ] Nonfatal weaknesses are not marked fatal.
- [ ] No model or precision identity was guessed or added.
- [ ] No unit text was edited.
- [ ] No discussion occurred with another reviewer.
- [ ] `completed_all_units` is true.
- [ ] `submission_complete` is true.

Return only the completed YAML or JSON review file plus, optionally, one short paragraph of overall
impressions. Do not include speculation about model identity.
